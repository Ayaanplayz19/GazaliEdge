import yfinance as yf
import statistics as stat
import datetime as dt
import pandas as pd
import mplfinance as mpl
import matplotlib.pyplot as plt
import os
from PyQt5.QtWidgets import (QApplication, QMainWindow, QLabel, QLineEdit, QPushButton, QTextEdit, QVBoxLayout, QWidget, QComboBox,QHBoxLayout,QMessageBox)
from PyQt5.QtGui import QColor, QPalette, QFont
from PyQt5.QtCore import Qt

import sys
import warnings
warnings.filterwarnings("ignore")

FILE_NAME = os.path.join(os.path.dirname(__file__), "finance_project_file.txt")# Function to create a new user account and save the information to the file

def ticker():
    global TICKER
    TICKER = str(input('Enter Ticker symbol: ')).upper()

def load_stocks_historic_prices():
    global data, ema_20, ema_50, ema_100, ema_200, rsi_14
    global upper_band, middle_band, lower_band, macd_line, signal_line, atr
    global current_price, stock, prices

    try:
        #TICKER CHECKER
        if 'TICKER' not in globals():
            print("Ticker symbol is not defined. Please set TICKER first.")
            return
        
        end_date = dt.datetime.today().strftime('%Y-%m-%d')
        data = yf.download(TICKER, start="2024-01-01", end=end_date, progress=False)

        if data.empty:
            print(f"Ticker symbol '{TICKER}' doesn't exist or is delisted.")
            return
        
        prices = data['Close'].tolist()

        # Calculating EMAs
        ema_20 = calculate_ema(prices, 20)
        ema_50 = calculate_ema(prices, 50)
        ema_100 = calculate_ema(prices, 100)
        ema_200 = calculate_ema(prices, 200)

        # Calculating other indicators
        rsi_14 = calculate_rsi(prices, 14)
        upper_band, middle_band, lower_band = calculate_bollinger_bands(prices)
        macd_line, signal_line = calculate_macd(prices)
        atr = calculate_atr(data)

        stock = yf.Ticker(TICKER)
        current_price = stock.info.get('currentPrice', "Price info not available")
    
    except Exception as e:
        print(f"An error occurred: {e}")
             
def stock_current_price():
    stock = yf.Ticker(TICKER)
    try:
        print('-------------------------------------------------------------------------------------------------------')
        price = stock.info['currentPrice']
        print(f'The price of {TICKER} is {price}')
    except:
        print('Something went wrong, try checking the Ticker Symbol')
        print('-------------------------------------------------------------------------------------------------------')

def get_current_price(ticker_symbol):
    try:
        stock = yf.Ticker(ticker_symbol)
        
        current_price = stock.info.get('regularMarketPrice')
        if current_price is None:
            current_price = stock.info.get('previousClose')  # if regularMarketPrice is missing
        if current_price is None:
            current_price = stock.info.get('bid')  # Another option inacse first one fails

        # Check if we found a normal ( not weird ) price
        if current_price is not None:
            return current_price
        else:
            return f"No price data available for ticker: {ticker_symbol}"
    
    except Exception as e:
        # Handle any exceptions and display an error message
        print(f"Error fetching data for {ticker_symbol}: {e}")
        return f"Unable to fetch current price for ticker: {ticker_symbol}"

def stock_fundamentals():
    stock = yf.Ticker(TICKER)
    info = stock.info
    volume=info['volume']
    mcap=info.get('marketCap','N/A')
    pe=info.get('trailingPE','N/A')
    eps=info.get('trailingEps','N/A')
    div=info.get('dividendYield','N/A')
    pb=info.get('priceToBook','N/A')
    beta=info.get('beta','N/A')

    #special formats (percentages and commas)
    volume = f'{volume:,}' if volume != 'N/A' else 'N/A'
    mcap = f'{mcap:,}' if mcap != 'N/A' else 'N/A'
    div = f'{div * 100:.2f}%' if div != 'N/A' else 'N/A'

    #dictionary to store all fundamental technical values
    fundamentals = {
        'Volume' : volume,
        'Market Cap' : mcap,
        'P/E Ratio' : pe,
        'EPS' : eps,
        'Dividend Yield' : div,
        'P/B Ratio' : pb,
        'Beta' : beta
        }
    
    print(f'Fundamental Data for {TICKER}:')
    for tech in fundamentals:
        print(f'{tech}: {fundamentals[tech]}')

def calculate_ema(prices, period):
    ema_values = []
    alpha = 2 / (period + 1)
    ema = sum(prices[:period]) / period
    ema_values.append(ema)

    for price in prices[period:]:
        ema = (price * alpha) + (ema * (1 - alpha))
        ema_values.append(ema)
    return ema_values

def calculate_bollinger_bands(prices, period=20, std_dev_factor=2):
    global upper_band, middle_band, lower_band
    try:
        if len(prices) < period:
            return None, None, None
        middle_band = sum(prices[-period:]) / period
        std_dev = stat.stdev(prices[-period:])
        upper_band = middle_band + (std_dev_factor * std_dev)
        lower_band = middle_band - (std_dev_factor * std_dev)
        return upper_band, middle_band, lower_band
    except:
        return False

def calculate_rsi(prices, period=14):
    global rsi
    if len(prices) < period:
        return None

    gains = []
    losses = []
    for i in range(1, period + 1):
        change = prices[-i] - prices[-i - 1]
        if change > 0:
            gains.append(change)
        else:
            losses.append(abs(change))

    average_gain = sum(gains) / period
    average_loss = sum(losses) / period

    if average_loss == 0:
        return 100
    rs = average_gain / average_loss
    rsi = 100 - (100 / (1 + rs))
    return rsi

def calculate_macd(prices, short_period=12, long_period=26, signal_period=9):
    short_ema = calculate_ema(prices, short_period)
    long_ema = calculate_ema(prices, long_period)
    macd_line = [short - long for short, long in zip(short_ema, long_ema)]
    signal_line = calculate_ema(macd_line, signal_period)
    return macd_line, signal_line

def calculate_atr(data, period=14):
    tr = []
    for i in range(1, len(data)):
        high = data['High'].iloc[i]
        low = data['Low'].iloc[i]
        prev_close = data['Close'].iloc[i - 1]
        tr.append(max(high - low, abs(high - prev_close), abs(low - prev_close)))

    atr = sum(tr[:period]) / period  # Initial ATR is basically the SMA of TR (but SMA is not needed for making the financial advice)
    atr_values = [atr]
    for i in range(period, len(tr)):
        atr = (atr_values[-1] * (period - 1) + tr[i]) / period
        atr_values.append(atr)
    return atr_values

def stock_indicators():
    prices = data['Close'].tolist()
    
    # Calculating EMA
    ema_20 = calculate_ema(prices, 20)
    ema_50 = calculate_ema(prices, 50)
    ema_100 = calculate_ema(prices, 100)
    ema_200 = calculate_ema(prices, 200)

    # Calculating Indicators (except ema)
    rsi_14 = calculate_rsi(prices, 14)
    upper_band, middle_band, lower_band = calculate_bollinger_bands(prices)
    macd_line, signal_line = calculate_macd(prices)
    atr = calculate_atr(data)

    print(f"\nTechnical Indicators for {TICKER}:")
    print(f"20-Day EMA: {ema_20[-1]:.2f}")
    print(f"50-Day EMA: {ema_50[-1]:.2f}")
    print(f"100-Day EMA: {ema_100[-1]:.2f}")
    print(f"200-Day EMA: {ema_200[-1]:.2f}")
    print(f"14-Day RSI: {rsi_14:.2f}")
    print(f"Bollinger Bands: Upper: {upper_band:.2f}, Middle: {middle_band:.2f}, Lower: {lower_band:.2f}")
    print(f"MACD Line: {macd_line[-1]:.2f}, Signal Line: {signal_line[-1]:.2f}")
    print(f"ATR: {atr[-1]:.2f}")

def stock_about_info():
    stock = yf.Ticker(TICKER)
    info = stock.info

    # Relevant Short Info
    company_name = info.get('longName', 'N/A')
    sector = info.get('sector', 'N/A')
    industry = info.get('industry', 'N/A')
    website = info.get('website', 'N/A')
    long_summary = info.get('longBusinessSummary', 'N/A')                   #long summary aka import stuff
    country = info.get('country', 'N/A')
    city = info.get('city', 'N/A')
    full_time_employees = info.get('fullTimeEmployees', 'N/A')

    print(f"Company Information for {company_name}:")
    print('-------------------------------------------------------------------------------------------------------')
    print(f"Sector: {sector}")
    print(f"Industry: {industry}")
    print(f"Country: {country}")
    print(f"City: {city}")
    print(f"Website: {website}")
    print(f"Full-Time Employees: {full_time_employees}")
    print('-------------------------------------------------------------------------------------------------------')
    print(f"Company Description:\n{long_summary}")
    print('-------------------------------------------------------------------------------------------------------')

def stock_buy_decision():
    bullish_signals = 0
    bearish_signals = 0
    advice = []
    prices = data['Close'].tolist()

    # EMA Analysis
    if current_price > ema_20[-1] and current_price > ema_50[-1]:
        bullish_signals += 1
        advice.append("Current price is above 20-day and 50-day EMAs, indicating an upward trend.")
    else:
        bearish_signals += 1
        advice.append("Current price is below key EMAs, indicating downward pressure.")

    # RSI Analysis
    if rsi_14 < 30:
        bullish_signals += 1
        advice.append("RSI is below 30, indicating the stock may be oversold and could rebound.")
    elif rsi_14 > 70:
        bearish_signals += 1
        advice.append("RSI is above 70, indicating the stock may be overbought and could see a pullback.")
    
    # MACD Analysis
    if macd_line[-1] > signal_line[-1]:
        bullish_signals += 1
        advice.append("MACD line is above the signal line, indicating bullish momentum.")
    else:
        bearish_signals += 1
        advice.append("MACD line is below the signal line, indicating bearish momentum.")

    # Bollinger Bands Analysis
    if current_price < lower_band:
        bullish_signals += 1
        advice.append("Current price is below the lower Bollinger Band, indicating the stock may be undervalued.")
    elif current_price > upper_band:
        bearish_signals += 1
        advice.append("Current price is above the upper Bollinger Band, indicating the stock may be overvalued.")

    # Decision based on all signals
    if bullish_signals > bearish_signals:
        final_advice = "Overall, the indicators suggest a bullish trend. This may be a good buy opportunity."
    elif bearish_signals > bullish_signals:
        final_advice = "The indicators suggest a bearish trend. It may be better to wait or sell."
    else:
        final_advice = "The market is showing mixed signals. Consider holding or further analysis."

    detailed_advice = "\n".join(advice)
    result = f"Stock Analysis Results:\n{detailed_advice}\n\nConclusion: {final_advice}"
    
    print (result)

'''
def calculate_profit(stock_owned, stock_price):
    try:
    
        

        # Calculate profit/loss percentage
        profit_percentage = ((current_price - float(stock_price)) / float(stock_price)) * 100
        return profit_percentage, current_price
    except Exception as e:
        print("Error fetching stock data:", e)
        return None, None
'''

def create_account():
    name = input("Enter your name: ")
    password = input("Enter a password: ")
    mobile = input("Enter your mobile number: ")
    cash = input("Enter the amount of money in your account (in cash): ")
    stock_owned = input("Enter the stock symbol you own (if none, leave blank): ").upper()
    stock_price = input(f"Enter the price at which you bought {stock_owned} (if none, enter 0): ") if stock_owned else "0"
    
    with open(FILE_NAME, "a") as file:
        file.write(f"{name},{password},{mobile},{cash},{stock_owned},{stock_price},0\n")
    
    print(f"Account created successfully for {name}.\n")

def login():
    # Function to log in an existing user and display profit/loss
    name = input("Enter your name: ")
    password = input("Enter your password: ")

    if not os.path.exists(FILE_NAME):
        print("No accounts found. Please create an account first.")
        return
    
    with open(FILE_NAME, "r") as file:
        users = file.readlines()
    
    for user in users:
        user_data = user.strip().split(",")
        if user_data[0] == name and user_data[1] == password:
            print(f"Welcome back, {name}!")
            print(f"Mobile Number: {user_data[2]}")
            print(f"Cash in Account: ${user_data[3]}")
            
            if user_data[4]:  # Stock is owned
                stock_owned = user_data[4]
                stock_price = user_data[5]
                profit = float(float(get_current_price(str(stock_owned)))-float(stock_price))
                
                print(f"Stock Owned: {stock_owned}")
                print(f"Price Bought: ${stock_price}")
                
                if profit is not None:
                    print(f"Current Stock Price: ${get_current_price(str(stock_owned)):.2f}")
                    print(f"Profit/Loss: {profit:.2f}")
                else:
                    print("Could not calculate profit/loss.")
            else:
                print("No stock owned.")
            return
    
    print("Invalid login details. Please try again.")

'''
def plot_stock_chart(ticker):
    end_date = dt.datetime.today()
    
    # Define date ranges for different time frames
    periods = {
        "1": ("30 days", end_date - dt.timedelta(days=30)),
        "2": ("3 months", end_date - dt.timedelta(days=90)),
        "3": ("6 months", end_date - dt.timedelta(days=180)),
        "4": ("1 year", end_date - dt.timedelta(days=365)),
        "5": ("5 years", end_date - dt.timedelta(days=5 * 365))
    }
    
    # Display options to the user
    print("Select the timeframe for the chart:")
    print("1. 30 days (Candlestick)")
    print("2. 3 months (Candlestick)")
    print("3. 6 months (Line)")
    print("4. 1 year (Line)")
    print("5. 5 years (Line)")
    
    # Get user input
    choice = input("Enter your choice (1-5): ")

    # Validate user input
    if choice not in periods:
        print("Invalid choice. Please select a number between 1 and 5.")
        return
    
    # Retrieve the selected period's details
    period_name, start_date = periods[choice]
    data = yf.download(ticker, start=start_date, end=end_date)

    # Check if the data is empty
    if data.empty:
        print(f"No data available for {ticker} for {period_name}.")
        return

    # Determine chart type based on period
    if choice in ["1", "2"]:  # Candlestick for shorter periods
        print(f"Displaying Candlestick Chart for {period_name}")
        mpl.plot(
            data,
            type='candle',
            title=f"{ticker} - {period_name} Candlestick Chart",
            style="charles",
            volume=True
        )
    else:  # Line chart for longer periods
        print(f"Displaying Line Chart for {period_name}")
        mpl.plot(
            data,
            type='line',
            title=f"{ticker} - {period_name} Line Chart",
            style="charles",
            volume=True
        )
'''

def plot_advanced_stock_chart(ticker, period="1y"):
    # Download stock data for the specified period
    data = yf.download(ticker, period=period)
    
    # Check if data is empty
    if data.empty:
        print(f"No data available for {ticker}.")
        return

    # Calculate Moving Averages
    data['MA20'] = data['Close'].rolling(window=20).mean()
    data['MA50'] = data['Close'].rolling(window=50).mean()

    # Calculate RSI
    delta = data['Close'].diff(1)
    gain = delta.where(delta > 0, 0)
    loss = -delta.where(delta < 0, 0)
    avg_gain = gain.rolling(window=14).mean()
    avg_loss = loss.rolling(window=14).mean()
    rs = avg_gain / avg_loss
    data['RSI'] = 100 - (100 / (1 + rs))

    # Prepare additional plots for volume and RSI
    add_plots = [
        mpl.make_addplot(data['MA20'], color='blue', width=1),  # 20-day MA on main price chart
        mpl.make_addplot(data['MA50'], color='orange', width=1), # 50-day MA on main price chart
        mpl.make_addplot(data['RSI'], panel=1, color='purple', ylabel='RSI')  # RSI on a separate panel
    ]

    # Plotting
    mpl.plot(
        data,
        type='candle',
        style='charles',
        volume=True,
        addplot=add_plots,
        title=f"{ticker} Stock Price with MA, Volume, and RSI",
        ylabel="Price",
        ylabel_lower="Volume"
    )

#####################################################################################################################################################################################################################################################################

class StockApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Finance Project GUI")
        self.setGeometry(100, 100, 800, 600)

        # Setting up main layout and widgets
        self.central_widget = QWidget(self)
        self.setCentralWidget(self.central_widget)
        layout = QVBoxLayout(self.central_widget)
        
        # Ticker symbol input
        self.ticker_input = QLineEdit(self)
        self.ticker_input.setPlaceholderText("Enter Ticker Symbol")
        layout.addWidget(self.ticker_input)

        # Create buttons for different functions
        self.create_button("Load Stock Data", self.load_stocks_historic_prices, layout)
        self.create_button("Current Price", self.display_current_price, layout)
        self.create_button("Stock Fundamentals", self.display_fundamentals, layout)
        self.create_button("Technical Indicators", self.display_indicators, layout)
        self.create_button("Trading Advice", self.stock_buy_decision, layout)
        self.create_button("Company Info", self.display_company_info, layout)
        self.create_button("Login to Account", self.login, layout)
        self.create_button("Create New Account", self.create_account, layout)
        self.create_button("Plot Stock Chart", self.plot_advanced_stock_chart, layout)

        # Display area
        self.result_display = QTextEdit(self)
        layout.addWidget(self.result_display)

        # Apply color theme
        self.apply_theme()

    def apply_theme(self):
        # Main colors
        main_bg = "#2E3440"       # Dark blue-gray
        accent_color = "#88C0D0"   # Soft teal
        text_color = "#D8DEE9"     # Light gray
        button_bg = "#4C566A"      # Medium gray for buttons
        entry_bg = "#3B4252"       # Darker gray for entry fields

        # Set main window background color
        self.setAutoFillBackground(True)
        palette = self.palette()
        palette.setColor(QPalette.Window, QColor(main_bg))
        self.setPalette(palette)

        # Set styles for widgets
        self.ticker_input.setStyleSheet(f"background-color: {entry_bg}; color: {text_color}; padding: 5px; border-radius: 5px;")
        self.result_display.setStyleSheet(f"background-color: {entry_bg}; color: {text_color}; padding: 10px; border-radius: 5px;")
    
    def create_button(self, text, function, layout):
        button = QPushButton(text, self)
        button.setStyleSheet(
            f"background-color: #4C566A; color: #D8DEE9; padding: 10px; border-radius: 5px;"
            f"font-weight: bold; font-size: 13px;"
            f"hover: {QColor('#88C0D0').name()};")
        button.clicked.connect(function)
        layout.addWidget(button)

    def get_ticker(self):
        return self.ticker_input.text().upper()

    def load_stocks_historic_prices(self):
        TICKER = self.get_ticker()
        try:
            # Define date range for historical data
            end_date = dt.datetime.today().strftime('%Y-%m-%d')
            start_date = "2024-01-01"  # Example start date for data

            # Download historical data using yfinance
            data = yf.download(TICKER, start=start_date, end=end_date, progress=False)
            
            if data.empty:
                self.result_display.setText(f"Ticker symbol '{TICKER}' doesn't exist or no data available.")
                return

            # Display historical data in the result_display
            data_text = data.tail(5).to_string()  # Showing only the last 5 entries for readability
            self.result_display.setText(f"Recent Historical Prices for {TICKER}:\n{data_text}")

        except Exception as e:
            self.result_display.setText(f"An error occurred while fetching data for {TICKER}: {e}")

    def display_current_price(self):
        TICKER = self.get_ticker()
        stock = yf.Ticker(TICKER)
        try:
            price = stock.info['currentPrice']
            self.result_display.setText(f"The price of {TICKER} is {price}")
        except:
            self.result_display.setText("Something went wrong. Check Ticker Symbol.")

    def calculate_ema(self, prices, period):
        ema_values = []
        alpha = 2 / (period + 1)
        ema = sum(prices[:period]) / period
        ema_values.append(ema)

        for price in prices[period:]:
            ema = (price * alpha) + (ema * (1 - alpha))
            ema_values.append(ema)
        return ema_values
    
    def calculate_bollinger_bands(self, prices, period=20, std_dev_factor=2):
        global upper_band, middle_band, lower_band
        try:
            if len(prices) < period:
                return None, None, None
            middle_band = sum(prices[-period:]) / period
            std_dev = stat.stdev(prices[-period:])
            upper_band = middle_band + (std_dev_factor * std_dev)
            lower_band = middle_band - (std_dev_factor * std_dev)
            return upper_band, middle_band, lower_band
        except:
            return False

    def calculate_rsi(self, prices, period=14):
        global rsi
        if len(prices) < period:
            return None

        gains = []
        losses = []
        for i in range(1, period + 1):
            change = prices[-i] - prices[-i - 1]
            if change > 0:
                gains.append(change)
            else:
                losses.append(abs(change))

        average_gain = sum(gains) / period
        average_loss = sum(losses) / period

        if average_loss == 0:
            return 100
        rs = average_gain / average_loss
        rsi = 100 - (100 / (1 + rs))
        return rsi

    def calculate_macd(self, prices, short_period=12, long_period=26, signal_period=9):
        short_ema = calculate_ema(prices, short_period)
        long_ema = calculate_ema(prices, long_period)
        macd_line = [short - long for short, long in zip(short_ema, long_ema)]
        signal_line = calculate_ema(macd_line, signal_period)
        return macd_line, signal_line

    def calculate_atr(self, data, period=14):
        tr = []
        for i in range(1, len(data)):
            high = data['High'].iloc[i]
            low = data['Low'].iloc[i]
            prev_close = data['Close'].iloc[i - 1]
            tr.append(max(high - low, abs(high - prev_close), abs(low - prev_close)))

        atr = sum(tr[:period]) / period  # Initial ATR is basically the SMA of TR (but SMA is not needed for making the financial advice)
        atr_values = [atr]
        for i in range(period, len(tr)):
            atr = (atr_values[-1] * (period - 1) + tr[i]) / period
            atr_values.append(atr)
        return atr_values

    def display_fundamentals(self):
        TICKER = self.get_ticker()
        stock = yf.Ticker(TICKER)
        info = stock.info
        volume = info.get('volume', 'N/A')
        mcap = info.get('marketCap', 'N/A')
        pe = info.get('trailingPE', 'N/A')
        eps = info.get('trailingEps', 'N/A')
        div = info.get('dividendYield', 'N/A')
        
        fundamentals = (f"Volume: {volume}\nMarket Cap: {mcap}\nP/E Ratio: {pe}\n"
                        f"EPS: {eps}\nDividend Yield: {div * 100 if div != 'N/A' else 'N/A'}%")
        self.result_display.setText(fundamentals)
    
    def display_indicators(self):
        TICKER = self.get_ticker()
        
        try:
            # Load historical data for calculations
            end_date = dt.datetime.today().strftime('%Y-%m-%d')
            start_date = "2000-01-01"
            data = yf.download(TICKER, start=start_date, end=end_date, progress=False)
            
            if data.empty:
                self.result_display.setText(f"No data available for ticker '{TICKER}'.")
                return

            # Get closing prices for indicators
            prices = data['Close'].tolist()

            # Calculate EMAs
            ema_20 = self.calculate_ema(prices, 20)[-1]
            ema_50 = self.calculate_ema(prices, 50)[-1]
            ema_100 = self.calculate_ema(prices, 100)[-1]
            ema_200 = self.calculate_ema(prices, 200)[-1]

            # Calculate RSI
            rsi_14 = self.calculate_rsi(prices, 14)

            # Calculate Bollinger Bands
            upper_band, middle_band, lower_band = self.calculate_bollinger_bands(prices)

            # Calculate MACD
            macd_line, signal_line = self.calculate_macd(prices)

            # Calculate ATR
            atr = self.calculate_atr(data)

            # Prepare output
            indicators_text = (
                f"Technical Indicators for {TICKER}:\n"
                f"20-Day EMA: {ema_20:.2f}\n"
                f"50-Day EMA: {ema_50:.2f}\n"
                f"100-Day EMA: {ema_100:.2f}\n"
                f"200-Day EMA: {ema_200:.2f}\n"
                f"14-Day RSI: {rsi_14:.2f}\n"
                f"Bollinger Bands: Upper: {upper_band:.2f}, Middle: {middle_band:.2f}, Lower: {lower_band:.2f}\n"
                f"MACD Line: {macd_line[-1]:.2f}, Signal Line: {signal_line[-1]:.2f}\n"
                f"ATR: {atr[-1]:.2f}"
            )
            
            # Display the indicators in the GUI
            self.result_display.setText(indicators_text)
            
        except Exception as e:
            self.result_display.setText(f"An error occurred while calculating indicators for {TICKER}: {e}")
  
    def stock_buy_decision(self):
        TICKER = self.get_ticker()
        
        try:
            # Load historical data
            end_date = dt.datetime.today().strftime('%Y-%m-%d')
            data = yf.download(TICKER, start="2000-01-01", end=end_date, progress=False)
            
            if data.empty:
                self.result_display.setText(f"No data available for ticker '{TICKER}'.")
                return
            
            # Fetch closing prices for indicators
            prices = data['Close'].tolist()
            current_price = prices[-1]
            
            # Calculate indicators
            ema_20 = self.calculate_ema(prices, 20)[-1]
            ema_50 = self.calculate_ema(prices, 50)[-1]
            rsi_14 = self.calculate_rsi(prices, 14)
            upper_band, middle_band, lower_band = self.calculate_bollinger_bands(prices)
            macd_line, signal_line = self.calculate_macd(prices)

            # Decision variables
            bullish_signals = 0
            bearish_signals = 0
            advice = []

            # EMA Analysis
            if current_price > ema_20 and current_price > ema_50:
                bullish_signals += 1
                advice.append("Price is above 20-day and 50-day EMAs, indicating upward momentum.")
            else:
                bearish_signals += 1
                advice.append("Price is below key EMAs, indicating possible downward momentum.")

            # RSI Analysis
            if rsi_14 < 30:
                bullish_signals += 1
                advice.append("RSI below 30, indicating the stock may be oversold.")
            elif rsi_14 > 70:
                bearish_signals += 1
                advice.append("RSI above 70, suggesting the stock may be overbought.")
            
            # MACD Analysis
            if macd_line[-1] > signal_line[-1]:
                bullish_signals += 1
                advice.append("MACD line is above the signal line, suggesting bullish momentum.")
            else:
                bearish_signals += 1
                advice.append("MACD line is below the signal line, indicating bearish sentiment.")

            # Bollinger Bands Analysis
            if current_price < lower_band:
                bullish_signals += 1
                advice.append("Price is below the lower Bollinger Band, indicating potential undervaluation.")
            elif current_price > upper_band:
                bearish_signals += 1
                advice.append("Price is above the upper Bollinger Band, indicating potential overvaluation.")

            # Compile trading advice based on signal count
            if bullish_signals > bearish_signals:
                final_advice = "Overall, the indicators suggest a bullish trend. This may be a good buy opportunity."
            elif bearish_signals > bullish_signals:
                final_advice = "The indicators suggest a bearish trend. It may be better to wait or consider selling."
            else:
                final_advice = "The market is showing mixed signals. Consider holding or further analysis."

            # Display results in GUI
            detailed_advice = "\n".join(advice)
            result = f"Trading Advice for {TICKER}:\n{detailed_advice}\n\nConclusion: {final_advice}"
            self.result_display.setText(result)
            
        except Exception as e:
            self.result_display.setText(f"An error occurred while generating advice for {TICKER}: {e}")
        
    def display_company_info(self):
        TICKER = self.get_ticker()
        stock = yf.Ticker(TICKER)
        info = stock.info
        
        # Formatting and displaying all relevant company information
        company_info = (
            f"Company: {info.get('longName', 'N/A')}\n"
            f"Ticker: {TICKER}\n"
            f"Sector: {info.get('sector', 'N/A')}\n"
            f"Industry: {info.get('industry', 'N/A')}\n"
            f"Country: {info.get('country', 'N/A')}\n"
            f"City: {info.get('city', 'N/A')}\n"
            f"Full-Time Employees: {info.get('fullTimeEmployees', 'N/A')}\n\n"
            
            f"Market Cap: {info.get('marketCap', 'N/A'):,}\n"
            f"P/E Ratio: {info.get('trailingPE', 'N/A')}\n"
            f"Dividend Yield: {info.get('dividendYield', 'N/A') * 100 if info.get('dividendYield') else 'N/A'}%\n"
            f"Price-to-Book Ratio: {info.get('priceToBook', 'N/A')}\n"
            f"Beta: {info.get('beta', 'N/A')}\n\n"
            
            f"Website: {info.get('website', 'N/A')}\n\n"
            f"Business Summary:\n{info.get('longBusinessSummary', 'N/A')}\n"
        )
        
        # Display the formatted company information in the GUI
        self.result_display.setText(company_info)
        
    def login(self):
        # Retrieve user input from GUI fields
        name = input("Enter your name: ")
        password = input("Enter your password: ")

        # Check if the user file exists
        if not os.path.exists(FILE_NAME):
            self.result_display.setText("No accounts found. Please create an account first.")
            return
        
        # Attempt to find user details in the file
        with open(FILE_NAME, "r") as file:
            users = file.readlines()
        
        # Search for matching credentials in the file
        for user in users:
            user_data = user.strip().split(",")
            if user_data[0] == name and user_data[1] == password:
                # Successful login
                self.result_display.setText(
                    f"Welcome back, {name}!\n\n"
                    f"Mobile Number: {user_data[2]}\n"
                    f"Cash in Account: ${user_data[3]}\n"
                )
                
                # Display stock ownership details if available
                if user_data[4]:  # Stock is owned
                    stock_owned = user_data[4]
                    stock_price = user_data[5]
                    
                    # Fetch current stock price and calculate profit/loss
                    current_price = get_current_price(stock_owned)
                    profit_loss = (current_price - float(stock_price)) * 100 / float(stock_price)
                    
                    self.result_display.append(
                        f"Stock Owned: {stock_owned}\n"
                        f"Price Bought: ${stock_price}\n"
                        f"Current Price: ${current_price}\n"
                        f"Profit/Loss: {profit_loss:.2f}%\n"
                    )
                else:
                    self.result_display.append("No stock owned.")
                return
        
        # If no matching user was found, display an error message
        self.result_display.setText("Invalid login details. Please try again.")
  
    def create_account(self):
        # Retrieve user input for account creation
        name = input("Enter your name: ")
        password = input("Enter a password: ")
        mobile = input("Enter your mobile number: ")
        cash = input("Enter the amount of money in your account (in cash): ")
        stock_owned = input("Enter the stock symbol you own (if none, leave blank): ").upper()
        stock_price = input(f"Enter the price at which you bought {stock_owned} (if none, enter 0): ") if stock_owned else "0"

        # Input validation
        if not name or not password or not mobile or not cash:
            self.result_display.setText("Please fill in all required fields.")
            return
        
        # If no stock is provided, set price to "0" by default
        if not stock_owned:
            stock_owned = "None"
            stock_price = "0"

        # Write the account information to the file
        with open(FILE_NAME, "a") as file:
            file.write(f"{name},{password},{mobile},{cash},{stock_owned},{stock_price},0\n")

        # Confirm account creation
        self.result_display.setText(f"Account successfully created for {name}.")
    
    def plot_advanced_stock_chart(self):
        # Retrieve ticker symbol from input
        TICKER = self.get_ticker()
        if not TICKER:
            self.result_display.setText("Please enter a valid ticker symbol.")
            return

        try:
            # Download stock data for the specified period
            data = yf.download(TICKER, period="1y")
            
            # Check if data is empty
            if data.empty:
                self.result_display.setText(f"No data available for ticker: {TICKER}")
                return

            # Calculate Moving Averages
            data['MA20'] = data['Close'].rolling(window=20).mean()
            data['MA50'] = data['Close'].rolling(window=50).mean()

            # Calculate RSI
            delta = data['Close'].diff(1)
            gain = delta.where(delta > 0, 0)
            loss = -delta.where(delta < 0, 0)
            avg_gain = gain.rolling(window=14).mean()
            avg_loss = loss.rolling(window=14).mean()
            rs = avg_gain / avg_loss
            data['RSI'] = 100 - (100 / (1 + rs))

            # Prepare additional plots for volume and RSI
            add_plots = [
                mpl.make_addplot(data['MA20'], color='blue', width=1),  # 20-day MA on main price chart
                mpl.make_addplot(data['MA50'], color='orange', width=1), # 50-day MA on main price chart
                mpl.make_addplot(data['RSI'], panel=1, color='purple', ylabel='RSI')  # RSI on a separate panel
            ]

            # Plotting
            mpl.plot(
                data,
                type='candle',
                style='charles',
                volume=True,
                addplot=add_plots,
                title=f"{TICKER} Stock Price with MA, Volume, and RSI",
                ylabel="Price",
                ylabel_lower="Volume"
            )

        except Exception as e:
            self.result_display.setText(f"An error occurred while plotting data for {TICKER}: {e}")

    '''    
    def plot_stock_chart(self):
        TICKER = self.get_ticker()
        data = yf.download(TICKER, period="1y")
        if data.empty:
            self.result_display.setText(f"No data available for {TICKER}")
            return
        mpl.plot(data, type='candle', style='charles', title=f"{TICKER} Stock Price")
    '''

# Main function
def main():
    #ticker()
    #plot_advanced_stock_chart(TICKER, period="1y")
    #ticker()
    #load_stocks_historic_prices()
    #print('hi')
    
    app = QApplication(sys.argv)
    window = StockApp()
    window.show()
    sys.exit(app.exec_())
    

if __name__ == '__main__':
    main()
